package com.cg.employee;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.cg.employee.sort.Sorting;
import com.cg.employee.sort.SortingAddress;
import com.cg.employee.validate.Validate;

	public class DetailsMain {
		
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);

			Map<Employee,String> hm = new HashMap<Employee, String>(); 
			Set<Address> addressList = new HashSet<Address>();

			while(true)
			{
			System.out.println("1. To add an Employee");
			System.out.println("2. Sort By Employee ID");
			System.out.println("3. Sort By First Name");
			System.out.println("4. Sort By Last Name");
			System.out.println("5. Sort By Salary");
			System.out.println("6. Sort By Address");
			System.out.println("7. Sort By Department");
			System.out.println("8. Exit");
			switch(sc.next()) {
		
			case "1": {
				
				Employee employee = new Employee();
				Department department = new Department();
				Validate validate = new Validate();
	
						
		    System.out.println("Enter Employee ID. For eg: 12345_FS");
		    String employeeId = sc.next();
		    if(validate.validateEmployeeId(employeeId)) {
		    	employee.setEmployeeId(employeeId);
		    	System.out.println("Employee ID Set");
		    }
		    else
		    {
		    	System.out.println("Error! Please enter valid Employee ID");
		    	break;
		    }
			System.out.println("Enter the first name (First Letter Capital)");
			String firstName = sc.next();
			if(validate.validateName(firstName)) {
				employee.setFirstName(firstName);
				System.out.println("Employee First Name set");
			}
			else
			{
				System.out.println("Error! Please enter valid First Name");
				break;
			}
     		System.out.println("Enter the last name (First Letter Capital)");
     		String lastName= sc.next();
     		if(validate.validateName(lastName)) {
			  employee.setLastName(lastName);
			  System.out.println("Employee Last Name set");
     		}
     		else {
     			System.out.println("Error! Please enter valid Last Name");
     			break;
     		}
			System.out.println("Enter the salary in the range (20,000 -5,00,000");
			double salary = sc.nextDouble();
			if(validate.validSalary(salary))
			{
		    employee.setSalary(salary);
		    System.out.println("Salary set");
			}
			else
			{
				System.out.println("Error! Please enter valid salary");
				break;
			}
			System.out.println("enter the DOJ");
			
	    	employee.setDateOfJoining(sc.next());
	
			System.out.println("Please enter other department related details");
			System.out.println("Please Enter Department ID");
			department.setDepartmentId(sc.next());
			System.out.println("Please Enter Department Name");
	        department.setDepartmentName(sc.next());
			System.out.println("Please Enter Department Location");
			department.setLocation(sc.next());
			employee.setDepartment(department);
			
			System.out.println("Please enter the number of addresses to be stored");
			int noOfAddress= sc.nextInt();
			
			
			for(int i=0;i < noOfAddress; i++)
			{
		    Address address = new Address();
		    System.out.println("Please Enter Address ID");
		 	address.setAddressId(sc.next());
			System.out.println("Please Enter Address Line 1");
		    address.setAddressLine1(sc.next());
			System.out.println("Please Enter City");
			address.setCity(sc.next());
		    System.out.println("Please Enter State");
			address.setState(sc.next());
			addressList.add(address);
			}
			employee.setAddress(addressList);
		    for(Address data: addressList) {
		         System.out.println(data);
		      }
		    System.out.println("Details saved! Thankyou and have a nice day");
		    
			hm.put(employee, employee.getEmployeeId());
			
			for(Map.Entry<Employee, String> entry : hm.entrySet())		 
			{
		 		 System.out.println(entry.getKey());
		 	 }
			break;
			      
			    } 
			case "2": {
			
			        List<Employee> keyList = new ArrayList(hm.keySet());
			        
			        Collections.sort(keyList, Sorting.EmployeeIdComparator); 
			        if(keyList.isEmpty())
			        {
			        	System.out.println("Please check your inputs");
			        }
			        else {
			        System.out.println("Sorted based on Employee Id");
			        keyList.forEach(System.out::println);
			        break;
					
			     }
			     }
            case "3": {
				
		        List<Employee> keyList = new ArrayList(hm.keySet());
		        
		        Collections.sort(keyList, Sorting.FirstNameComparator); 
		        if(keyList.isEmpty())
		        {
		        	System.out.println("Please check your inputs");
		        }
		        else {
		        System.out.println("Sorted based on First Name");
		        keyList.forEach(System.out::println);
				break;
	         	}
			    }
	
			case "4": {
				
		        List<Employee> keyList = new ArrayList(hm.keySet());
		        
		        Collections.sort(keyList, Sorting.LastNameComparator); 
		        if(keyList.isEmpty())
		        {
		        	System.out.println("Please check your inputs");
		        }
		        else {
		        System.out.println("Sorted based on Last Name");
		        keyList.forEach(System.out::println);
				break;
	         	}
		     	}
		        case "5": 
		        {
		        List<Employee> keyList = new ArrayList(hm.keySet());
				        
				Collections.sort(keyList, Sorting.SalaryComparator); 
				 if(keyList.isEmpty())
				    {
				     System.out.println("Please check your inputs");
				    }
				  else {
				   System.out.println("Sorted based on Salary");
				   keyList.forEach(System.out::println);
				   break;
		        }
		        }
			        
		        case "6": 
		        {
		        	List<Address> list = new ArrayList<Address>(addressList);
				Collections.sort(list, SortingAddress.AddressComparator); 
				if(addressList.isEmpty())
				  {
				   System.out.println("Please check your inputs");
				  }
			   else{
				   System.out.println("Sorted based on Address");
				   addressList.forEach(System.out::println);
				   break;
		        }
		        }
		        
		        case "7": 
		        {
		        List<Employee> keyList = new ArrayList(hm.keySet());
				        
				Collections.sort(keyList, Sorting.DepartmentComparator); 
				 if(keyList.isEmpty())
				    {
				     System.out.println("Please check your inputs");
				    }
				  else {
				   System.out.println("Sorted based on Department");
				   keyList.forEach(System.out::println);
				   break;
		        }
		        }
		        case "8" :
		        	System.out.println("Thank you!");
		        	System.exit(0);
		        default :
		            System.out.println("Enter valid number");
	}
		}
	
		}
	}
package com.cg.employee.sort;

import java.util.Comparator;

import com.cg.employee.Address;

public class SortingAddress implements Comparable<Address> {
	  
	public static final Comparator<Address> AddressComparator = new Comparator<Address>(){

	    @Override
	    public int compare(Address add1,Address add2) {
			return add1.getAddressId().compareTo(add2.getAddressId());
		}
	 	};
	
	@Override
	public int compareTo(Address o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
